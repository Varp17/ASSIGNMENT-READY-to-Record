import React, { useState, useEffect, useCallback } from "react";
import { AuthContext } from "./AuthContext";
import { getProfile } from "../services/api";


/**
 * AuthProvider
 * - Manages authenticated user session
 * - Loads profile from /auth/me if token exists
 * - Persists login token in localStorage
 * - Exposes login, logout, and refresh utilities
 */
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch current logged-in user (if token exists)
  const loadUser = useCallback(async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      setUser(null);
      setLoading(false);
      return;
    }

    try {
      const res = await getProfile();
      // Support both {user} and {success, user} shapes
      const userData = res.data?.user || res.data;
      setUser(userData);
    } catch (err) {
      console.warn("Auth load failed:", err.response?.data?.message || err.message);
      localStorage.removeItem("token");
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  // Login -> save token + set user
  const login = (userData, token) => {
    if (token) localStorage.setItem("token", token);
    setUser(userData);
  };

  // Logout -> remove token + clear state
  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
  };

  // Optional: manually reload user (after update, etc.)
  const refresh = () => loadUser();

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        logout,
        refresh,
        setUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
